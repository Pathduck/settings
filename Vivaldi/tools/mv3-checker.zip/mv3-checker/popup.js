const manifestVersion = chrome.runtime.getManifest().manifest_version;
let result = `Manifest version in use: ${manifestVersion}<br>`;

if (chrome.action) {
  result += "✅ MV3 API (chrome.action) is available.";
} else {
  result += "❌ MV3 API (chrome.action) is missing.";
}

document.getElementById("result").innerHTML = result;