console.log("MV3 Checker loaded.");
console.log("Manifest version:", chrome.runtime.getManifest().manifest_version);

if (chrome.action) {
  console.log("✅ chrome.action exists → MV3 APIs available.");
} else {
  console.log("❌ chrome.action missing → MV3 APIs disabled.");
}