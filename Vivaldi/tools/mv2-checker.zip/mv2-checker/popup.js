const manifestVersion = chrome.runtime.getManifest().manifest_version;
let result = `Manifest version in use: ${manifestVersion}<br>`;

if (chrome.browserAction) {
  result += "✅ MV2 API (chrome.browserAction) is available.";
} else {
  result += "❌ MV2 API (chrome.browserAction) is missing.";
}

document.getElementById("result").innerHTML = result;
