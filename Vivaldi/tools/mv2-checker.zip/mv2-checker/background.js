console.log("MV2 Checker loaded.");
console.log("Manifest version:", chrome.runtime.getManifest().manifest_version);

if (chrome.browserAction) {
  console.log("✅ chrome.browserAction exists → MV2 APIs available.");
} else {
  console.log("❌ chrome.browserAction missing → MV2 APIs disabled.");
}
