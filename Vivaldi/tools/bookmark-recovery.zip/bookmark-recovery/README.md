# [Chrome Bookmarks Recovery Tool](https://rongjiecomputer.github.io/chrome/bookmark-recovery/)

This is a tool written in JavaScript that converts the Chrome native bookmarks file (`Bookmarks` or `Bookmarks.bak`) into HTML file which can be imported back to Chrome via Bookmark Manager.

## Contributors
Special thanks to David King, Hennie Rozengarden, Jeroen Van Antwerpen, Cor Koomen and other TC/RS Chromies in refining this tool.
